#!/bin/bash

# 监控的 CPU 使用率下限
CPU_THRESHOLD=10
# 矿工路径
MINER_DIR="/home/pian/桌面/cryptix-miner-linux64-v-0-2-7"
cd "$MINER_DIR"

# 获取本机 IP 地址的第四位
IP_FOURTH_OCTET=$(hostname -I | awk '{print $1}' | awk -F '.' '{print $4}')

# 获取最大线程数
THREADS=$(nproc)

# 矿工命令
MINER_CMD="./cryptix-miner -s stratum+tcp://stratum.cryptix-network.org:13094 --mining-address cryptix:qpqckeundk8kx5p09mlfyyaedf4cfh4xjur9g322u2jzkamy2kvuyfd6lp0q5.$IP_FOURTH_OCTET --threads $THREADS"


# 启动 miner
nohup $MINER_CMD > miner.log 2>&1 &

# 监控循环
while true; do
    # 获取 miner 进程 ID
    MINER_PID=$(pidof cryptix-miner)

    if [ -n "$MINER_PID" ]; then
        # 获取 CPU 使用率（只取第一个进程）
        CPU_USAGE=$(ps -p $MINER_PID -o %cpu --no-headers | awk 'NR==1 {print int($1)}' | grep -Eo '[0-9]+')

        # 检查 CPU 是否过低
        if [ -n "$CPU_USAGE" ] && [ "$CPU_USAGE" -lt "$CPU_THRESHOLD" ]; then
            echo "$(date): CPU usage is $CPU_USAGE%, restarting miner..." >> monitor.log

            # 终止 miner
            pkill -f "cryptix-miner"

            # 重启 miner
            nohup $MINER_CMD > miner.log 2>&1 &
        else
            echo "$(date): CPU usage is $CPU_USAGE%, no action needed." >> monitor.log
        fi
    else
        echo "$(date): miner process not found, starting..." >> monitor.log
        nohup $MINER_CMD > miner.log 2>&1 &
    fi

    # 休眠 60 秒
    sleep 60
done
